# metaplex-nft
library to create nft on Solana blockchain based on Metaplex nft and candymachine
