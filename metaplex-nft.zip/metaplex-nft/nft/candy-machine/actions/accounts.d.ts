import * as anchor from '@project-serum/anchor';
import { web3 } from '@project-serum/anchor';
import { Keypair, PublicKey } from '@solana/web3.js';
import BN from 'bn.js';
import { WebWalletSigner } from '../../candy-machine/types';
export declare const createConfig: (anchorProgram: anchor.Program, payerWallet: Keypair, configData: {
    maxNumberOfLines: BN;
    symbol: string;
    sellerFeeBasisPoints: number;
    isMutable: boolean;
    maxSupply: BN;
    retainAuthority: boolean;
    creators: {
        address: PublicKey;
        verified: boolean;
        share: number;
    }[];
}, cacheName: string, env: string, cacheStorage: any) => Promise<{
    config: anchor.web3.PublicKey;
    uuid: string;
    txId: string;
}>;
export declare function uuidFromConfigPubkey(configAccount: PublicKey): string;
export declare const getTokenWallet: (wallet: PublicKey, mint: PublicKey) => Promise<anchor.web3.PublicKey>;
export declare const getCandyMachineAddress: (config: anchor.web3.PublicKey, uuid: string) => Promise<[PublicKey, number]>;
export declare const getConfig: (authority: anchor.web3.PublicKey, uuid: string) => Promise<[PublicKey, number]>;
export declare const getTokenMint: (authority: anchor.web3.PublicKey, uuid: string) => Promise<[anchor.web3.PublicKey, number]>;
export declare const getFairLaunch: (tokenMint: anchor.web3.PublicKey) => Promise<[anchor.web3.PublicKey, number]>;
export declare const getFairLaunchTicket: (tokenMint: anchor.web3.PublicKey, buyer: anchor.web3.PublicKey) => Promise<[anchor.web3.PublicKey, number]>;
export declare const getFairLaunchTicketSeqLookup: (tokenMint: anchor.web3.PublicKey, seq: anchor.BN) => Promise<[anchor.web3.PublicKey, number]>;
export declare const getAtaForMint: (mint: anchor.web3.PublicKey, buyer: anchor.web3.PublicKey) => Promise<[anchor.web3.PublicKey, number]>;
export declare const getTreasury: (tokenMint: anchor.web3.PublicKey) => Promise<[anchor.web3.PublicKey, number]>;
export declare const getMetadata: (mint: anchor.web3.PublicKey) => Promise<anchor.web3.PublicKey>;
export declare const getMasterEdition: (mint: anchor.web3.PublicKey) => Promise<anchor.web3.PublicKey>;
export declare function loadWalletKey(keypair: any): Keypair;
export declare function loadCandyProgram(walletKeyPair: Keypair | WebWalletSigner, env: string): Promise<anchor.Program>;
//# sourceMappingURL=accounts.d.ts.map