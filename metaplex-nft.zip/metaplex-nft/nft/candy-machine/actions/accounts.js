"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadCandyProgram = exports.loadWalletKey = exports.getMasterEdition = exports.getMetadata = exports.getTreasury = exports.getAtaForMint = exports.getFairLaunchTicketSeqLookup = exports.getFairLaunchTicket = exports.getFairLaunch = exports.getTokenMint = exports.getConfig = exports.getCandyMachineAddress = exports.getTokenWallet = exports.uuidFromConfigPubkey = exports.createConfig = void 0;
const anchor = __importStar(require("@project-serum/anchor"));
const anchor_1 = require("@project-serum/anchor");
const web3_js_1 = require("@solana/web3.js");
const constants_1 = require("../../common/constants");
const instructions_1 = require("./instructions");
const cache_1 = require("./cache");
const helpers_1 = require("../../utils/helpers");
const logger_1 = __importDefault(require("../../utils/logger"));
const createConfig = async function (anchorProgram, payerWallet, configData, cacheName, env, cacheStorage) {
    const configAccount = web3_js_1.Keypair.generate();
    const uuid = uuidFromConfigPubkey(configAccount.publicKey);
    const savedContent = (0, cache_1.loadCache)(cacheName, env, cacheStorage);
    const cacheContent = savedContent || {};
    cacheContent.configSecureStore = (0, helpers_1.encryptString)(configAccount);
    (0, cache_1.saveCache)(cacheName, env, cacheContent, cacheStorage);
    return {
        config: configAccount.publicKey,
        uuid,
        txId: await anchorProgram.rpc.initializeConfig({
            uuid,
            ...configData,
        }, {
            accounts: {
                config: configAccount.publicKey,
                authority: payerWallet.publicKey,
                payer: payerWallet.publicKey,
                systemProgram: web3_js_1.SystemProgram.programId,
                rent: anchor.web3.SYSVAR_RENT_PUBKEY,
            },
            signers: [payerWallet, configAccount],
            instructions: [
                await (0, instructions_1.createConfigAccount)(anchorProgram, configData, payerWallet.publicKey, configAccount.publicKey),
            ],
        }),
    };
};
exports.createConfig = createConfig;
function uuidFromConfigPubkey(configAccount) {
    return configAccount.toBase58().slice(0, 6);
}
exports.uuidFromConfigPubkey = uuidFromConfigPubkey;
const getTokenWallet = async function (wallet, mint) {
    return (await web3_js_1.PublicKey.findProgramAddress([wallet.toBuffer(), constants_1.TOKEN_PROGRAM_ID.toBuffer(), mint.toBuffer()], constants_1.SPL_ASSOCIATED_TOKEN_ACCOUNT_PROGRAM_ID))[0];
};
exports.getTokenWallet = getTokenWallet;
const getCandyMachineAddress = async (config, uuid) => {
    return await anchor.web3.PublicKey.findProgramAddress([Buffer.from(constants_1.CANDY_MACHINE), config.toBuffer(), Buffer.from(uuid)], constants_1.CANDY_MACHINE_PROGRAM_ID);
};
exports.getCandyMachineAddress = getCandyMachineAddress;
const getConfig = async (authority, uuid) => {
    return await anchor.web3.PublicKey.findProgramAddress([Buffer.from(constants_1.CANDY_MACHINE), authority.toBuffer(), Buffer.from(uuid)], constants_1.CANDY_MACHINE_PROGRAM_ID);
};
exports.getConfig = getConfig;
const getTokenMint = async (authority, uuid) => {
    return await anchor.web3.PublicKey.findProgramAddress([
        Buffer.from('fair_launch'),
        authority.toBuffer(),
        Buffer.from('mint'),
        Buffer.from(uuid),
    ], constants_1.FAIR_LAUNCH_PROGRAM_ID);
};
exports.getTokenMint = getTokenMint;
const getFairLaunch = async (tokenMint) => {
    return await anchor.web3.PublicKey.findProgramAddress([Buffer.from('fair_launch'), tokenMint.toBuffer()], constants_1.FAIR_LAUNCH_PROGRAM_ID);
};
exports.getFairLaunch = getFairLaunch;
const getFairLaunchTicket = async (tokenMint, buyer) => {
    return await anchor.web3.PublicKey.findProgramAddress([Buffer.from('fair_launch'), tokenMint.toBuffer(), buyer.toBuffer()], constants_1.FAIR_LAUNCH_PROGRAM_ID);
};
exports.getFairLaunchTicket = getFairLaunchTicket;
const getFairLaunchTicketSeqLookup = async (tokenMint, seq) => {
    return await anchor.web3.PublicKey.findProgramAddress([Buffer.from('fair_launch'), tokenMint.toBuffer(), seq.toBuffer('le', 8)], constants_1.FAIR_LAUNCH_PROGRAM_ID);
};
exports.getFairLaunchTicketSeqLookup = getFairLaunchTicketSeqLookup;
const getAtaForMint = async (mint, buyer) => {
    return await anchor.web3.PublicKey.findProgramAddress([buyer.toBuffer(), constants_1.TOKEN_PROGRAM_ID.toBuffer(), mint.toBuffer()], constants_1.SPL_ASSOCIATED_TOKEN_ACCOUNT_PROGRAM_ID);
};
exports.getAtaForMint = getAtaForMint;
const getTreasury = async (tokenMint) => {
    return await anchor.web3.PublicKey.findProgramAddress([Buffer.from('fair_launch'), tokenMint.toBuffer(), Buffer.from('treasury')], constants_1.FAIR_LAUNCH_PROGRAM_ID);
};
exports.getTreasury = getTreasury;
const getMetadata = async (mint) => {
    return (await anchor.web3.PublicKey.findProgramAddress([
        Buffer.from('metadata'),
        constants_1.TOKEN_METADATA_PROGRAM_ID.toBuffer(),
        mint.toBuffer(),
    ], constants_1.TOKEN_METADATA_PROGRAM_ID))[0];
};
exports.getMetadata = getMetadata;
const getMasterEdition = async (mint) => {
    return (await anchor.web3.PublicKey.findProgramAddress([
        Buffer.from('metadata'),
        constants_1.TOKEN_METADATA_PROGRAM_ID.toBuffer(),
        mint.toBuffer(),
        Buffer.from('edition'),
    ], constants_1.TOKEN_METADATA_PROGRAM_ID))[0];
};
exports.getMasterEdition = getMasterEdition;
function loadWalletKey(keypair) {
    if (!keypair || keypair === '') {
        throw new Error('Keypair is required!');
    }
    const loaded = web3_js_1.Keypair.fromSecretKey(new Uint8Array(keypair));
    logger_1.default.info(`wallet public key: ${loaded.publicKey}`);
    return loaded;
}
exports.loadWalletKey = loadWalletKey;
async function loadCandyProgram(walletKeyPair, env) {
    // @ts-ignore
    const solConnection = new anchor_1.web3.Connection(anchor_1.web3.clusterApiUrl(env));
    let walletWrapper;
    if (walletKeyPair instanceof web3_js_1.Keypair) {
        walletWrapper = new anchor.Wallet(walletKeyPair);
    }
    else {
        walletWrapper = walletKeyPair;
    }
    const provider = new anchor.Provider(solConnection, walletWrapper, {
        preflightCommitment: 'recent',
    });
    const idl = await anchor.Program.fetchIdl(constants_1.CANDY_MACHINE_PROGRAM_ID, provider);
    // @ts-ignore
    const program = new anchor.Program(idl, constants_1.CANDY_MACHINE_PROGRAM_ID, provider);
    logger_1.default.debug('program id from anchor', program.programId.toBase58());
    return program;
}
exports.loadCandyProgram = loadCandyProgram;
