export declare function loadCache(cacheName: string, env: string, cacheStorage: any): any;
export declare function saveCache(cacheName: string, env: string, cacheContent: any, cacheStorage: any): void;
//# sourceMappingURL=cache.d.ts.map