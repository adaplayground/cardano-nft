"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveCache = exports.loadCache = void 0;
function loadCache(cacheName, env, cacheStorage) {
    const path = `${env}-${cacheName}`;
    return path in cacheStorage ? JSON.parse(cacheStorage[path]) : undefined;
}
exports.loadCache = loadCache;
function saveCache(cacheName, env, cacheContent, cacheStorage) {
    cacheContent.env = env;
    cacheContent.cacheName = cacheName;
    const path = `${env}-${cacheName}`;
    cacheStorage[path] = JSON.stringify(cacheContent);
}
exports.saveCache = saveCache;
