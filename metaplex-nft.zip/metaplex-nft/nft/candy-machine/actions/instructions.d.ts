/// <reference types="node" />
import * as anchor from '@project-serum/anchor';
import { PublicKey, TransactionInstruction } from '@solana/web3.js';
export declare function createAssociatedTokenAccountInstruction(associatedTokenAddress: PublicKey, payer: PublicKey, walletAddress: PublicKey, splTokenMintAddress: PublicKey): anchor.web3.TransactionInstruction;
export declare const prepPayForDeveloperTxn: (wallet: PublicKey, extraMintPrice?: string) => Promise<{
    instructions: TransactionInstruction[];
}>;
export declare function createMetadataInstruction(metadataAccount: PublicKey, mint: PublicKey, mintAuthority: PublicKey, payer: PublicKey, updateAuthority: PublicKey, txnData: Buffer): anchor.web3.TransactionInstruction;
export declare function createConfigAccount(anchorProgram: any, configData: any, payerWallet: any, configAccount: any): Promise<anchor.web3.TransactionInstruction>;
//# sourceMappingURL=instructions.d.ts.map