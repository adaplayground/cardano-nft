"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createConfigAccount = exports.createMetadataInstruction = exports.prepPayForDeveloperTxn = exports.createAssociatedTokenAccountInstruction = void 0;
//@ts-ignore
const anchor = __importStar(require("@project-serum/anchor"));
const web3_js_1 = require("@solana/web3.js");
const constants_1 = require("../../common/constants");
const various_1 = require("./various");
function createAssociatedTokenAccountInstruction(associatedTokenAddress, payer, walletAddress, splTokenMintAddress) {
    const keys = [
        {
            pubkey: payer,
            isSigner: true,
            isWritable: true,
        },
        {
            pubkey: associatedTokenAddress,
            isSigner: false,
            isWritable: true,
        },
        {
            pubkey: walletAddress,
            isSigner: false,
            isWritable: false,
        },
        {
            pubkey: splTokenMintAddress,
            isSigner: false,
            isWritable: false,
        },
        {
            pubkey: web3_js_1.SystemProgram.programId,
            isSigner: false,
            isWritable: false,
        },
        {
            pubkey: constants_1.TOKEN_PROGRAM_ID,
            isSigner: false,
            isWritable: false,
        },
        {
            pubkey: web3_js_1.SYSVAR_RENT_PUBKEY,
            isSigner: false,
            isWritable: false,
        },
    ];
    return new web3_js_1.TransactionInstruction({
        keys,
        programId: constants_1.SPL_ASSOCIATED_TOKEN_ACCOUNT_PROGRAM_ID,
        data: Buffer.from([]),
    });
}
exports.createAssociatedTokenAccountInstruction = createAssociatedTokenAccountInstruction;
const prepPayForDeveloperTxn = async (wallet, extraMintPrice = '0') => {
    const instructions = [];
    const lamports = extraMintPrice ? (0, various_1.parsePrice)(extraMintPrice) : 0;
    if (wallet)
        instructions.push(web3_js_1.SystemProgram.transfer({
            fromPubkey: wallet,
            toPubkey: constants_1.IPFS_SOL_HOLDER_ID,
            lamports: 2300000 + lamports, // 0.0023 SOL  (paid to ipfs storage fee)
        }));
    return {
        instructions,
    };
};
exports.prepPayForDeveloperTxn = prepPayForDeveloperTxn;
function createMetadataInstruction(metadataAccount, mint, mintAuthority, payer, updateAuthority, txnData) {
    const keys = [
        {
            pubkey: metadataAccount,
            isSigner: false,
            isWritable: true,
        },
        {
            pubkey: mint,
            isSigner: false,
            isWritable: false,
        },
        {
            pubkey: mintAuthority,
            isSigner: true,
            isWritable: false,
        },
        {
            pubkey: payer,
            isSigner: true,
            isWritable: false,
        },
        {
            pubkey: updateAuthority,
            isSigner: false,
            isWritable: false,
        },
        {
            pubkey: web3_js_1.SystemProgram.programId,
            isSigner: false,
            isWritable: false,
        },
        {
            pubkey: web3_js_1.SYSVAR_RENT_PUBKEY,
            isSigner: false,
            isWritable: false,
        },
    ];
    return new web3_js_1.TransactionInstruction({
        keys,
        programId: constants_1.TOKEN_METADATA_PROGRAM_ID,
        data: txnData,
    });
}
exports.createMetadataInstruction = createMetadataInstruction;
async function createConfigAccount(anchorProgram, configData, payerWallet, configAccount) {
    const size = constants_1.CONFIG_ARRAY_START +
        4 +
        configData.maxNumberOfLines.toNumber() * constants_1.CONFIG_LINE_SIZE +
        4 +
        Math.ceil(configData.maxNumberOfLines.toNumber() / 8);
    const lamports = await anchorProgram.provider.connection.getMinimumBalanceForRentExemption(size);
    return anchor.web3.SystemProgram.createAccount({
        fromPubkey: payerWallet,
        newAccountPubkey: configAccount,
        space: size,
        lamports: lamports,
        programId: constants_1.CANDY_MACHINE_PROGRAM_ID,
    });
}
exports.createConfigAccount = createConfigAccount;
