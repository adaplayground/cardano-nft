import { Blockhash, Commitment, Connection, FeeCalculator, Keypair, Transaction, TransactionInstruction } from '@solana/web3.js';
import { WebWalletSigner } from '../../candy-machine/types';
interface BlockhashAndFeeCalculator {
    blockhash: Blockhash;
    feeCalculator: FeeCalculator;
}
export declare const getErrorForTransaction: (connection: Connection, txid: string) => Promise<string[]>;
export declare function sendTransactionWithRetry(connection: Connection, wallet: WebWalletSigner | Keypair, instructions: TransactionInstruction[], signers: Keypair[], commitment?: Commitment, includesFeePayer?: boolean, block?: BlockhashAndFeeCalculator, beforeSend?: () => void): Promise<{
    txid: string;
    slot: number;
}>;
export declare function sendSignedTransaction({ signedTransaction, connection, timeout, }: {
    signedTransaction: Transaction;
    connection: Connection;
    sendingMessage?: string;
    sentMessage?: string;
    successMessage?: string;
    timeout?: number;
}): Promise<{
    txid: string;
    slot: number;
}>;
export {};
//# sourceMappingURL=transactions.d.ts.map