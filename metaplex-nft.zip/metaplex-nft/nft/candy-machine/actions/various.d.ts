import { AccountInfo } from '@solana/web3.js';
export declare const getUnixTs: () => number;
export declare function sleep(ms: number): Promise<void>;
export declare function fromUTF8Array(data: number[]): string;
export declare function parsePrice(price: string, mantissa?: number): number;
export declare function parseDate(date: any): number;
export declare const getMultipleAccounts: (connection: any, keys: string[], commitment: string) => Promise<{
    keys: string[];
    array: AccountInfo<Buffer>[];
}>;
export declare function chunks(array: any, size: any): any[];
export declare function generateRandoms(numberOfAttrs?: number, total?: number): number[];
export declare const getMetadata: (name: string | undefined, symbol: string | undefined, index: number | undefined, creators: any, description: string | undefined, seller_fee_basis_points: number | undefined, attrs: any, collection: any) => {
    name: string;
    symbol: string;
    image: string;
    properties: {
        files: {
            uri: string;
            type: string;
        }[];
        category: string;
        creators: any;
    };
    description: string;
    seller_fee_basis_points: number;
    attributes: any[];
    collection: any;
};
//# sourceMappingURL=various.d.ts.map