"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMetadata = exports.generateRandoms = exports.chunks = exports.getMultipleAccounts = exports.parseDate = exports.parsePrice = exports.fromUTF8Array = exports.sleep = exports.getUnixTs = void 0;
const web3_js_1 = require("@solana/web3.js");
const path_1 = __importDefault(require("path"));
const getUnixTs = () => {
    return new Date().getTime() / 1000;
};
exports.getUnixTs = getUnixTs;
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
exports.sleep = sleep;
function fromUTF8Array(data) {
    // array of bytes
    let str = '', i;
    for (i = 0; i < data.length; i++) {
        const value = data[i];
        if (value < 0x80) {
            str += String.fromCharCode(value);
        }
        else if (value > 0xbf && value < 0xe0) {
            str += String.fromCharCode(((value & 0x1f) << 6) | (data[i + 1] & 0x3f));
            i += 1;
        }
        else if (value > 0xdf && value < 0xf0) {
            str += String.fromCharCode(((value & 0x0f) << 12) |
                ((data[i + 1] & 0x3f) << 6) |
                (data[i + 2] & 0x3f));
            i += 2;
        }
        else {
            // surrogate pair
            const charCode = (((value & 0x07) << 18) |
                ((data[i + 1] & 0x3f) << 12) |
                ((data[i + 2] & 0x3f) << 6) |
                (data[i + 3] & 0x3f)) -
                0x010000;
            str += String.fromCharCode((charCode >> 10) | 0xd800, (charCode & 0x03ff) | 0xdc00);
            i += 3;
        }
    }
    return str;
}
exports.fromUTF8Array = fromUTF8Array;
function parsePrice(price, mantissa = web3_js_1.LAMPORTS_PER_SOL) {
    return Math.ceil(parseFloat(price) * mantissa);
}
exports.parsePrice = parsePrice;
function parseDate(date) {
    if (date === 'now') {
        return Date.now() / 1000;
    }
    return Date.parse(date) / 1000;
}
exports.parseDate = parseDate;
const getMultipleAccounts = async (connection, keys, commitment) => {
    const result = await Promise.all(chunks(keys, 99).map(chunk => getMultipleAccountsCore(connection, chunk, commitment)));
    const array = result
        .map(a => 
    //@ts-ignore
    a.array.map(acc => {
        if (!acc) {
            return undefined;
        }
        const { data, ...rest } = acc;
        const obj = {
            ...rest,
            data: Buffer.from(data[0], 'base64'),
        };
        return obj;
    }))
        //@ts-ignore
        .flat();
    return { keys, array };
};
exports.getMultipleAccounts = getMultipleAccounts;
function chunks(array, size) {
    return Array.apply(0, new Array(Math.ceil(array.length / size))).map((_, index) => array.slice(index * size, (index + 1) * size));
}
exports.chunks = chunks;
function generateRandoms(numberOfAttrs = 1, total = 100) {
    const numbers = [];
    const loose_percentage = total / numberOfAttrs;
    for (let i = 0; i < numberOfAttrs; i++) {
        const random = Math.floor(Math.random() * loose_percentage) + 1;
        numbers.push(random);
    }
    const sum = numbers.reduce((prev, cur) => {
        return prev + cur;
    }, 0);
    numbers.push(total - sum);
    return numbers;
}
exports.generateRandoms = generateRandoms;
const getMetadata = (name = '', symbol = '', index = 0, creators, description = '', seller_fee_basis_points = 500, attrs, collection) => {
    const attributes = [];
    for (const prop in attrs) {
        attributes.push({
            trait_type: prop,
            value: path_1.default.parse(attrs[prop]).name,
        });
    }
    return {
        name: `${name}${index + 1}`,
        symbol,
        image: `${index}.png`,
        properties: {
            files: [
                {
                    uri: `${index}.png`,
                    type: 'image/png',
                },
            ],
            category: 'image',
            creators,
        },
        description,
        seller_fee_basis_points,
        attributes,
        collection,
    };
};
exports.getMetadata = getMetadata;
const getMultipleAccountsCore = async (connection, keys, commitment) => {
    const args = connection._buildArgs([keys], commitment, 'base64');
    const unsafeRes = await connection._rpcRequest('getMultipleAccounts', args);
    if (unsafeRes.error) {
        throw new Error('failed to get info about account ' + unsafeRes.error.message);
    }
    if (unsafeRes.result.value) {
        const array = unsafeRes.result.value;
        return { keys, array };
    }
    // TODO: fix
    throw new Error();
};
