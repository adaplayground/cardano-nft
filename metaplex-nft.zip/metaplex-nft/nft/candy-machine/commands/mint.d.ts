import { PublicKey } from '@solana/web3.js';
export declare function mint(keypair: any, configAddress: PublicKey, env: string, cacheName: string, cacheStorage: any, extraMintPrice?: string): Promise<string>;
//# sourceMappingURL=mint.d.ts.map