"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mint = void 0;
const anchor = __importStar(require("@project-serum/anchor"));
const spl_token_1 = require("@solana/spl-token");
const web3_js_1 = require("@solana/web3.js");
const accounts_1 = require("../../candy-machine/actions/accounts");
const constants_1 = require("../../common/constants");
const instructions_1 = require("../../candy-machine/actions/instructions");
const transactions_1 = require("../../candy-machine/actions/transactions");
const cache_1 = require("../../candy-machine/actions//cache");
const helpers_1 = require("../../utils/helpers");
async function mint(keypair, configAddress, env, cacheName, cacheStorage, extraMintPrice = '0') {
    const mint = web3_js_1.Keypair.generate();
    const userKeyPair = keypair;
    const anchorProgram = await (0, accounts_1.loadCandyProgram)(userKeyPair, env);
    const userTokenAccountAddress = await (0, accounts_1.getTokenWallet)(userKeyPair.publicKey, mint.publicKey);
    const uuid = (0, accounts_1.uuidFromConfigPubkey)(configAddress);
    const [candyMachineAddress] = await (0, accounts_1.getCandyMachineAddress)(configAddress, uuid);
    const candyMachine = await anchorProgram.account.candyMachine.fetch(candyMachineAddress);
    const remainingAccounts = [];
    const signers = [mint];
    if (keypair instanceof web3_js_1.Keypair) {
        signers.push(userKeyPair);
    }
    const { instructions: pushInstructions } = await (0, instructions_1.prepPayForDeveloperTxn)(userKeyPair.publicKey, extraMintPrice);
    const instructions = [
        ...pushInstructions,
        anchor.web3.SystemProgram.createAccount({
            fromPubkey: userKeyPair.publicKey,
            newAccountPubkey: mint.publicKey,
            space: spl_token_1.MintLayout.span,
            lamports: await anchorProgram.provider.connection.getMinimumBalanceForRentExemption(spl_token_1.MintLayout.span),
            programId: constants_1.TOKEN_PROGRAM_ID,
        }),
        spl_token_1.Token.createInitMintInstruction(constants_1.TOKEN_PROGRAM_ID, mint.publicKey, 0, userKeyPair.publicKey, userKeyPair.publicKey),
        (0, instructions_1.createAssociatedTokenAccountInstruction)(userTokenAccountAddress, userKeyPair.publicKey, userKeyPair.publicKey, mint.publicKey),
        spl_token_1.Token.createMintToInstruction(constants_1.TOKEN_PROGRAM_ID, mint.publicKey, userTokenAccountAddress, userKeyPair.publicKey, [], 1),
    ];
    let tokenAccount;
    if (candyMachine.tokenMint) {
        const transferAuthority = anchor.web3.Keypair.generate();
        tokenAccount = await (0, accounts_1.getTokenWallet)(userKeyPair.publicKey, candyMachine.tokenMint);
        remainingAccounts.push({
            pubkey: tokenAccount,
            isWritable: true,
            isSigner: false,
        });
        remainingAccounts.push({
            pubkey: userKeyPair.publicKey,
            isWritable: false,
            isSigner: true,
        });
        instructions.push(spl_token_1.Token.createApproveInstruction(constants_1.TOKEN_PROGRAM_ID, tokenAccount, transferAuthority.publicKey, userKeyPair.publicKey, [], candyMachine.data.price.toNumber()));
    }
    const metadataAddress = await (0, accounts_1.getMetadata)(mint.publicKey);
    const masterEdition = await (0, accounts_1.getMasterEdition)(mint.publicKey);
    instructions.push(await anchorProgram.instruction.mintNft({
        accounts: {
            config: configAddress,
            candyMachine: candyMachineAddress,
            payer: userKeyPair.publicKey,
            //@ts-ignore
            wallet: candyMachine.wallet,
            mint: mint.publicKey,
            metadata: metadataAddress,
            masterEdition,
            mintAuthority: userKeyPair.publicKey,
            updateAuthority: userKeyPair.publicKey,
            tokenMetadataProgram: constants_1.TOKEN_METADATA_PROGRAM_ID,
            tokenProgram: constants_1.TOKEN_PROGRAM_ID,
            systemProgram: web3_js_1.SystemProgram.programId,
            rent: anchor.web3.SYSVAR_RENT_PUBKEY,
            clock: anchor.web3.SYSVAR_CLOCK_PUBKEY,
        },
        remainingAccounts,
    }));
    if (tokenAccount) {
        instructions.push(spl_token_1.Token.createRevokeInstruction(constants_1.TOKEN_PROGRAM_ID, tokenAccount, userKeyPair.publicKey, []));
    }
    const cacheContent = (0, cache_1.loadCache)(cacheName, env, cacheStorage);
    cacheContent.metadataAddress = metadataAddress;
    cacheContent.mintAddress = mint.publicKey.toBase58();
    cacheContent.metadataSecureStore = (0, helpers_1.encryptString)(mint);
    (0, cache_1.saveCache)(cacheName, env, cacheContent, cacheStorage);
    return (await (0, transactions_1.sendTransactionWithRetry)(anchorProgram.provider.connection, userKeyPair, instructions, signers)).txid;
}
exports.mint = mint;
