import { Keypair, PublicKey, TransactionInstruction } from '@solana/web3.js';
export declare function signMetadata(metadata: string, keypair: Keypair, env: string): Promise<void>;
export declare function signMetadataInstruction(metadata: PublicKey, creator: PublicKey): TransactionInstruction;
//# sourceMappingURL=sign.d.ts.map