import { Connection, Keypair } from '@solana/web3.js';
export declare function signAllMetadataFromCandyMachine(connection: Connection, wallet: Keypair, candyMachineAddress: string, batchSize: number, daemon: boolean): Promise<void>;
//# sourceMappingURL=signAll.d.ts.map