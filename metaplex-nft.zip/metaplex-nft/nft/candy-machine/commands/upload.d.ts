import { Keypair } from '@solana/web3.js';
export declare function uploadSimple(images: any, manifestContents: any, cacheName: string, env: string, keypair: Keypair, totalNFTs: number, retainAuthority: boolean, cacheStorage: any): Promise<boolean>;
//# sourceMappingURL=upload.d.ts.map