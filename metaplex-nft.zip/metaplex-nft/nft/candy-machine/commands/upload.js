"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadSimple = void 0;
const web3_js_1 = require("@solana/web3.js");
const bn_js_1 = __importDefault(require("bn.js"));
const accounts_1 = require("../../candy-machine/actions/accounts");
const cache_1 = require("../../candy-machine/actions/cache");
const various_1 = require("../../candy-machine/actions/various");
const logger_1 = __importDefault(require("../../utils/logger"));
const ipfs_1 = require("../../candy-machine/ipfs");
async function uploadSimple(images, manifestContents, cacheName, env, keypair, totalNFTs, retainAuthority, cacheStorage) {
    let uploadSuccessful = true;
    let savedContent = (0, cache_1.loadCache)(cacheName, env, cacheStorage);
    let cacheContent = savedContent || {};
    if (!cacheContent.program) {
        cacheContent.program = {};
    }
    if (!cacheContent.items) {
        cacheContent.items = [];
    }
    const SIZE = images.length;
    const walletKeyPair = keypair;
    const anchorProgram = await (0, accounts_1.loadCandyProgram)(walletKeyPair, env);
    let config = cacheContent.program.config
        ? new web3_js_1.PublicKey(cacheContent.program.config)
        : undefined;
    for (let i = 0; i < SIZE; i++) {
        const image = images[i];
        const index = i;
        logger_1.default.debug(`Processing file: ${i}`);
        if (i % 50 === 0) {
            logger_1.default.info(`Processing file: ${i}`);
        }
        let link = cacheContent?.items?.[index]?.link;
        if (!link || !cacheContent.program.uuid) {
            const manifestContent = manifestContents[i];
            const manifest = manifestContent;
            const manifestBuffer = Buffer.from(JSON.stringify(manifest));
            if (i === 0 && !cacheContent.program.uuid) {
                // initialize config
                logger_1.default.info(`initializing config`);
                try {
                    (0, cache_1.saveCache)(cacheName, env, cacheContent, cacheStorage);
                    const res = await (0, accounts_1.createConfig)(anchorProgram, walletKeyPair, {
                        maxNumberOfLines: new bn_js_1.default(totalNFTs),
                        symbol: manifest.symbol,
                        sellerFeeBasisPoints: manifest.seller_fee_basis_points,
                        isMutable: true,
                        maxSupply: new bn_js_1.default(0),
                        retainAuthority: retainAuthority,
                        creators: manifest.properties.creators.map(creator => {
                            return {
                                address: new web3_js_1.PublicKey(creator.address),
                                verified: true,
                                share: creator.share,
                            };
                        }),
                    }, cacheName, env, cacheStorage);
                    savedContent = (0, cache_1.loadCache)(cacheName, env, cacheStorage);
                    cacheContent = savedContent || {};
                    cacheContent.program.uuid = res.uuid;
                    cacheContent.program.config = res.config.toBase58();
                    config = res.config;
                    logger_1.default.info(`initialized config for a candy machine with publickey: ${res.config.toBase58()}`);
                    (0, cache_1.saveCache)(cacheName, env, cacheContent, cacheStorage);
                }
                catch (exx) {
                    logger_1.default.error('Error deploying config to Solana network.', exx);
                    throw exx;
                }
            }
            if (!link) {
                try {
                    // link = await arweaveUpload(
                    //   walletKeyPair,
                    //   anchorProgram,
                    //   env,
                    //   image,
                    //   manifestBuffer,
                    //   manifest,
                    //   index,
                    // );
                    link = await (0, ipfs_1.ipfsUpload)(ipfs_1.ipfsConfig, image, manifestBuffer);
                    if (link) {
                        logger_1.default.debug('setting cache for ', index);
                        cacheContent.items[index] = {
                            link,
                            name: manifest.name,
                            onChain: false,
                        };
                        cacheContent.authority = walletKeyPair.publicKey.toBase58();
                        (0, cache_1.saveCache)(cacheName, env, cacheContent, cacheStorage);
                    }
                }
                catch (er) {
                    uploadSuccessful = false;
                    logger_1.default.error(`Error uploading file ${index}`, er);
                }
            }
        }
    }
    const keys = Object.keys(cacheContent.items);
    try {
        await Promise.all((0, various_1.chunks)(Array.from(Array(keys.length).keys()), 1000).map(async (allIndexesInSlice) => {
            for (let offset = 0; offset < allIndexesInSlice.length; offset += 10) {
                const indexes = allIndexesInSlice.slice(offset, offset + 10);
                const onChain = indexes.filter(i => {
                    const index = keys[i];
                    return cacheContent.items[index]?.onChain || false;
                });
                const ind = keys[indexes[0]];
                if (onChain.length !== indexes.length) {
                    logger_1.default.info(`Writing indices ${ind}-${keys[indexes[indexes.length - 1]]}`);
                    try {
                        await anchorProgram.rpc.addConfigLines(
                        // @ts-ignore
                        ind, indexes.map(i => ({
                            uri: cacheContent.items[keys[i]].link,
                            name: cacheContent.items[keys[i]].name,
                        })), {
                            accounts: {
                                config,
                                authority: walletKeyPair.publicKey,
                            },
                            signers: [walletKeyPair],
                        });
                        indexes.forEach(i => {
                            cacheContent.items[keys[i]] = {
                                ...cacheContent.items[keys[i]],
                                onChain: true,
                            };
                        });
                        (0, cache_1.saveCache)(cacheName, env, cacheContent, cacheStorage);
                    }
                    catch (e) {
                        logger_1.default.error(`saving config line ${ind}-${keys[indexes[indexes.length - 1]]} failed`, e);
                        uploadSuccessful = false;
                    }
                }
            }
        }));
    }
    catch (e) {
        logger_1.default.error(e);
    }
    finally {
        (0, cache_1.saveCache)(cacheName, env, cacheContent, cacheStorage);
    }
    return uploadSuccessful;
}
exports.uploadSimple = uploadSimple;
