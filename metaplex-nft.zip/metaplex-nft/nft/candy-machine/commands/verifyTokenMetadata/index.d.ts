declare type TokenMetadata = {
    image: string;
    properties: {
        files: {
            uri: string;
            type: string;
        }[];
        creators: {
            address: string;
            share: number;
        }[];
    };
};
export declare const verifyAssets: ({ files, uploadElementsCount }: {
    files: any;
    uploadElementsCount: any;
}) => void;
export declare const verifyAggregateShare: (creators: TokenMetadata['properties']['creators'], manifestFile: any) => void;
declare type CollatedCreators = Map<string, {
    shares: Set<number>;
    tokenCount: number;
}>;
export declare const verifyCreatorCollation: (creators: TokenMetadata['properties']['creators'], collatedCreators: CollatedCreators, manifestFile: string) => void;
export declare const verifyImageURL: (image: any, files: any, manifestFile: any) => void;
export declare const verifyConsistentShares: (collatedCreators: CollatedCreators) => void;
export declare const verifyMetadataManifests: ({ files }: {
    files: any;
}) => void;
export declare const verifyTokenMetadata: ({ files, uploadElementsCount, }: {
    files: any;
    uploadElementsCount?: null | undefined;
}) => Boolean;
export {};
//# sourceMappingURL=index.d.ts.map