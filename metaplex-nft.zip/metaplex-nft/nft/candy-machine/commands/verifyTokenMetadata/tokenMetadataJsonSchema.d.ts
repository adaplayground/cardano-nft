export declare const tokenMetadataJsonSchema: {
    title: string;
    type: string;
    properties: {
        name: {
            type: string;
            description: string;
        };
        description: {
            type: string;
            description: string;
        };
        image: {
            type: string;
            description: string;
        };
        external_url: {
            type: string;
            description: string;
        };
        seller_fee_basis_points: {
            type: string;
            description: string;
            minimum: number;
            maximum: number;
        };
        properties: {
            type: string;
            description: string;
            properties: {
                files: {
                    type: string;
                    items: {
                        type: string;
                        properties: {
                            uri: {
                                type: string;
                            };
                            type: {
                                type: string;
                                description: string;
                            };
                        };
                    };
                };
                creators: {
                    type: string;
                    description: string;
                    items: {
                        type: string;
                        properties: {
                            address: {
                                type: string;
                                description: string;
                                pattern: string;
                            };
                            share: {
                                type: string;
                                description: string;
                                exclusiveMinimum: number;
                                maximum: number;
                            };
                        };
                    };
                };
            };
        };
    };
};
//# sourceMappingURL=tokenMetadataJsonSchema.d.ts.map