import { MintMonitor, WebWalletSigner } from '../candy-machine/types';
import { processCreateCandyMachine, processGetInfo, processMintOneToken, processSignMeta, processUpdateCandyMachine, processUpload, processVerify } from '../candy-machine/operations';
import { Keypair } from '@solana/web3.js';
export declare enum MintStatus {
    UpLoad = 1,
    Verify = 2,
    Create = 3,
    Update = 4,
    Mint = 5,
    Sign = 6,
    Info = 7,
    Error = 8
}
export declare const getMintStatusMessage: (status: MintStatus) => "Uploading" | "signing" | "Updating meta data" | "Verifying meta data" | "Creating meta data" | "Minting" | "Retrieving information" | "Detected errors";
export { processUpload, processVerify, processCreateCandyMachine, processUpdateCandyMachine, processMintOneToken, processSignMeta, processGetInfo, };
export declare function makeCandyMachine(image: string, //base64 png images as in sample assets\image0.ts
meta: any, // meta json as in sample assets\0.json
payerKeypair: any, solTreasuryAccount: any, env: string, price: string, retainAuthority: boolean, mintMonitor: MintMonitor): Promise<{}>;
export declare function buyerBuyNftFromCandyMachine(buyerKeypair: Keypair | WebWalletSigner, env: string, cacheStorage: any, mintMonitor: MintMonitor, extraMintPrice?: string): Promise<{}>;
export declare function diyMintOneNftWithCandyMachine(image: string, meta: any, keypair: any, env: string, price: string, retainAuthority: boolean, mintMonitor: MintMonitor, extraMintPrice?: string): Promise<any>;
//# sourceMappingURL=index.d.ts.map