"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.diyMintOneNftWithCandyMachine = exports.buyerBuyNftFromCandyMachine = exports.makeCandyMachine = exports.processGetInfo = exports.processSignMeta = exports.processMintOneToken = exports.processUpdateCandyMachine = exports.processCreateCandyMachine = exports.processVerify = exports.processUpload = exports.getMintStatusMessage = exports.MintStatus = void 0;
const operations_1 = require("../candy-machine/operations");
Object.defineProperty(exports, "processCreateCandyMachine", { enumerable: true, get: function () { return operations_1.processCreateCandyMachine; } });
Object.defineProperty(exports, "processGetInfo", { enumerable: true, get: function () { return operations_1.processGetInfo; } });
Object.defineProperty(exports, "processMintOneToken", { enumerable: true, get: function () { return operations_1.processMintOneToken; } });
Object.defineProperty(exports, "processSignMeta", { enumerable: true, get: function () { return operations_1.processSignMeta; } });
Object.defineProperty(exports, "processUpdateCandyMachine", { enumerable: true, get: function () { return operations_1.processUpdateCandyMachine; } });
Object.defineProperty(exports, "processUpload", { enumerable: true, get: function () { return operations_1.processUpload; } });
Object.defineProperty(exports, "processVerify", { enumerable: true, get: function () { return operations_1.processVerify; } });
const logger_1 = __importDefault(require("../utils/logger"));
var MintStatus;
(function (MintStatus) {
    MintStatus[MintStatus["UpLoad"] = 1] = "UpLoad";
    MintStatus[MintStatus["Verify"] = 2] = "Verify";
    MintStatus[MintStatus["Create"] = 3] = "Create";
    MintStatus[MintStatus["Update"] = 4] = "Update";
    MintStatus[MintStatus["Mint"] = 5] = "Mint";
    MintStatus[MintStatus["Sign"] = 6] = "Sign";
    MintStatus[MintStatus["Info"] = 7] = "Info";
    MintStatus[MintStatus["Error"] = 8] = "Error";
})(MintStatus = exports.MintStatus || (exports.MintStatus = {}));
const getMintStatusMessage = (status) => {
    switch (status) {
        case MintStatus.UpLoad:
            return `Uploading`;
        case MintStatus.Sign:
            return `signing`;
        case MintStatus.Update:
            return `Updating meta data`;
        case MintStatus.Verify:
            return `Verifying meta data`;
        case MintStatus.Create:
            return `Creating meta data`;
        case MintStatus.Mint:
            return `Minting`;
        case MintStatus.Info:
            return `Retrieving information`;
        case MintStatus.Error:
            return `Detected errors`;
    }
};
exports.getMintStatusMessage = getMintStatusMessage;
//this is used to create candy machine before sell.
//1. makeCandyMachine
//2.     -->buyerBuyNftFromCandyMachine
//3. mintOneNft (Mint on demand only need one step)
//4. diyMintOneNftWithCandyMachine (normally not needed because of extra cost)
async function makeCandyMachine(image, //base64 png images as in sample assets\image0.ts
meta, // meta json as in sample assets\0.json
payerKeypair, solTreasuryAccount, env, price, retainAuthority, mintMonitor) {
    const cacheStorage = {};
    const cacheName = 'cache';
    const currentDate = new Date().toISOString();
    const tokenPrice = '1';
    try {
        const success = await (0, operations_1.processUpload)(image, meta, payerKeypair, env, cacheName, retainAuthority, cacheStorage);
        if (mintMonitor) {
            if (success) {
                mintMonitor(MintStatus.UpLoad, cacheStorage);
            }
        }
        await (0, operations_1.processVerify)(payerKeypair, env, cacheName, cacheStorage);
        if (mintMonitor) {
            mintMonitor(MintStatus.Verify, cacheStorage);
        }
        await (0, operations_1.processCreateCandyMachine)(tokenPrice, payerKeypair, env, cacheName, cacheStorage, null, null, solTreasuryAccount);
        if (mintMonitor) {
            mintMonitor(MintStatus.Create, cacheStorage);
        }
        await (0, operations_1.processUpdateCandyMachine)(price, currentDate, payerKeypair, env, cacheName, cacheStorage);
        if (mintMonitor) {
            mintMonitor(MintStatus.Update, cacheStorage);
        }
    }
    catch (e) {
        if (mintMonitor) {
            mintMonitor(MintStatus.Error, cacheStorage);
            logger_1.default.log(e);
        }
    }
    return cacheStorage;
}
exports.makeCandyMachine = makeCandyMachine;
//this is for buyer to buy that NFT from candy machine.
async function buyerBuyNftFromCandyMachine(buyerKeypair, env, cacheStorage, mintMonitor, extraMintPrice = '0') {
    let cacheContent = {};
    const cacheName = 'cache';
    try {
        await (0, operations_1.processMintOneToken)(buyerKeypair, env, cacheName, cacheStorage, extraMintPrice);
        if (mintMonitor) {
            mintMonitor(MintStatus.Mint, cacheStorage);
        }
        cacheContent = await (0, operations_1.processGetInfo)(buyerKeypair, env, cacheName, cacheStorage);
        if (mintMonitor) {
            mintMonitor(MintStatus.Info, cacheStorage);
        }
    }
    catch (e) {
        if (mintMonitor) {
            mintMonitor(MintStatus.Error, cacheStorage);
        }
    }
    return cacheContent;
}
exports.buyerBuyNftFromCandyMachine = buyerBuyNftFromCandyMachine;
// this in theory should not needed, pay extra fee for candy machine
async function diyMintOneNftWithCandyMachine(image, meta, keypair, env, price, retainAuthority, mintMonitor, extraMintPrice = '0') {
    const cacheStorage = {};
    const cacheName = 'cache';
    const currentDate = new Date().toISOString();
    const tokenPrice = '1';
    try {
        const success = await (0, operations_1.processUpload)(image, meta, keypair, env, cacheName, retainAuthority, cacheStorage);
        if (mintMonitor) {
            if (success) {
                mintMonitor(MintStatus.UpLoad, cacheStorage);
            }
        }
        await (0, operations_1.processVerify)(keypair, env, cacheName, cacheStorage);
        if (mintMonitor) {
            mintMonitor(MintStatus.Verify, cacheStorage);
        }
        await (0, operations_1.processCreateCandyMachine)(tokenPrice, keypair, env, cacheName, cacheStorage);
        if (mintMonitor) {
            mintMonitor(MintStatus.Create, cacheStorage);
        }
        await (0, operations_1.processUpdateCandyMachine)(price, currentDate, keypair, env, cacheName, cacheStorage);
        if (mintMonitor) {
            mintMonitor(MintStatus.Update, cacheStorage);
        }
        await (0, operations_1.processMintOneToken)(keypair, env, cacheName, cacheStorage, extraMintPrice);
        if (mintMonitor) {
            mintMonitor(MintStatus.Mint, cacheStorage);
        }
        const cacheContent = await (0, operations_1.processGetInfo)(keypair, env, cacheName, cacheStorage);
        if (mintMonitor) {
            mintMonitor(MintStatus.Info, cacheStorage);
        }
        logger_1.default.log(cacheContent);
        return cacheContent;
    }
    catch (e) {
        if (mintMonitor) {
            mintMonitor(MintStatus.Error, cacheStorage);
            logger_1.default.log(e);
        }
        return null;
    }
}
exports.diyMintOneNftWithCandyMachine = diyMintOneNftWithCandyMachine;
