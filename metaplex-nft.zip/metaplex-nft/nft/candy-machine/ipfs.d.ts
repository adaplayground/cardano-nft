/// <reference types="node" />
export interface ipfsCreds {
    projectId: string;
    secretKey: string;
}
export declare let ipfsConfig: ipfsCreds;
export declare const initIpfs: (cred: ipfsCreds) => void;
export declare function ipfsUpload(ipfsCredentials: ipfsCreds, image: string, manifestBuffer: Buffer): Promise<string>;
export declare function ipfsUploadWithMediaLink(ipfsCredentials: ipfsCreds, mediaUrl: string, manifestBuffer: Buffer): Promise<string>;
//# sourceMappingURL=ipfs.d.ts.map