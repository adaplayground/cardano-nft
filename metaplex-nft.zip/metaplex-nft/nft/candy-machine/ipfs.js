"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ipfsUploadWithMediaLink = exports.ipfsUpload = exports.initIpfs = exports.ipfsConfig = void 0;
const node_fetch_1 = __importDefault(require("node-fetch"));
const ipfs_http_client_1 = require("ipfs-http-client");
const logger_1 = __importDefault(require("../utils/logger"));
exports.ipfsConfig = {
    projectId: '',
    secretKey: '',
};
const initIpfs = (cred) => {
    exports.ipfsConfig.projectId = cred.projectId;
    exports.ipfsConfig.secretKey = cred.secretKey;
};
exports.initIpfs = initIpfs;
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
async function ipfsUpload(ipfsCredentials, image, manifestBuffer) {
    const tokenIfps = `${ipfsCredentials.projectId}:${ipfsCredentials.secretKey}`;
    // @ts-ignore
    const ipfs = (0, ipfs_http_client_1.create)('https://ipfs.infura.io:5001');
    const uploadToIpfs = async (source) => {
        const { cid } = await ipfs.add(source).catch();
        return cid;
    };
    const buffer = Buffer.from(image, 'base64');
    // @ts-ignore
    const mediaHash = await uploadToIpfs(buffer);
    logger_1.default.debug('mediaHash:', mediaHash);
    const mediaUrl = `https://ipfs.io/ipfs/${mediaHash}`;
    logger_1.default.debug('mediaUrl:', mediaUrl);
    const authIFPS = Buffer.from(tokenIfps).toString('base64');
    await (0, node_fetch_1.default)(`https://ipfs.infura.io:5001/api/v0/pin/add?arg=${mediaHash}`, {
        headers: {
            Authorization: `Basic ${authIFPS}`,
        },
        method: 'POST',
    });
    await sleep(1000);
    logger_1.default.info('uploaded image for file');
    const manifestJson = JSON.parse(manifestBuffer.toString('utf8'));
    manifestJson.image = mediaUrl;
    manifestJson.properties.files = manifestJson.properties.files.map(f => {
        return { ...f, uri: mediaUrl };
    });
    const manifestHash = await uploadToIpfs(Buffer.from(JSON.stringify(manifestJson)));
    await (0, node_fetch_1.default)(`https://ipfs.infura.io:5001/api/v0/pin/add?arg=${manifestHash}`, {
        headers: {
            Authorization: `Basic ${authIFPS}`,
        },
        method: 'POST',
    });
    await sleep(1000);
    const link = `https://ipfs.io/ipfs/${manifestHash}`;
    logger_1.default.info('uploaded manifest: ', link);
    return link;
}
exports.ipfsUpload = ipfsUpload;
async function ipfsUploadWithMediaLink(ipfsCredentials, mediaUrl, manifestBuffer) {
    const tokenIfps = `${ipfsCredentials.projectId}:${ipfsCredentials.secretKey}`;
    // @ts-ignore
    const ipfs = (0, ipfs_http_client_1.create)('https://ipfs.infura.io:5001');
    const uploadToIpfs = async (source) => {
        const { cid } = await ipfs.add(source).catch();
        return cid;
    };
    const authIFPS = Buffer.from(tokenIfps).toString('base64');
    const manifestJson = JSON.parse(manifestBuffer.toString('utf8'));
    manifestJson.image = mediaUrl;
    manifestJson.properties.files = manifestJson.properties.files.map(f => {
        return { ...f, uri: mediaUrl };
    });
    const manifestHash = await uploadToIpfs(Buffer.from(JSON.stringify(manifestJson)));
    await (0, node_fetch_1.default)(`https://ipfs.infura.io:5001/api/v0/pin/add?arg=${manifestHash}`, {
        headers: {
            Authorization: `Basic ${authIFPS}`,
        },
        method: 'POST',
    });
    await sleep(1000);
    const link = `https://ipfs.io/ipfs/${manifestHash}`;
    logger_1.default.info('uploaded manifest: ', link);
    return link;
}
exports.ipfsUploadWithMediaLink = ipfsUploadWithMediaLink;
