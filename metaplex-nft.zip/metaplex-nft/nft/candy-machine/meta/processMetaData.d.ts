import { ProcessAccountsFunc } from '../../common/types/meta-types';
export declare const processMetaData: ProcessAccountsFunc;
//# sourceMappingURL=processMetaData.d.ts.map