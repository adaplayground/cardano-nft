import { Connection, Keypair } from '@solana/web3.js';
import { WebWalletSigner } from '../candy-machine/types';
export declare function processUpload(image: string, meta: any, payerKeypair: any, env: string, cacheName: string, retainAuthority: boolean, cacheStorage: any): Promise<boolean>;
export declare function processVerify(payerKeypair: Keypair, env: string, cacheName: string, cacheStorage: any): Promise<void>;
export declare function processCreateCandyMachine(price: string, payerKeypair: Keypair, env: string, cacheName: string, cacheStorage: any, splToken?: any, splTokenAccount?: any, solTreasuryAccount?: any): Promise<void>;
export declare function processUpdateCandyMachine(price: string, date: string, payerKeypair: Keypair, env: string, cacheName: string, cacheStorage: any): Promise<void>;
export declare function processMintOneToken(buyerKeypair: Keypair | WebWalletSigner, env: string, cacheName: string, cacheStorage: any, extraMintPrice?: string): Promise<void>;
export declare function processSignMeta(creatorKeypair: Keypair, env: string, cacheName: string, cacheStorage: any): Promise<void>;
export declare function processGetInfo(keypair: Keypair | WebWalletSigner, env: string, cacheName: string, cacheStorage: any): Promise<any>;
export declare const transferOneNft: (tokenMintAddress: string, wallet: Keypair, to: string, connection: Connection) => Promise<void>;
//# sourceMappingURL=operations.d.ts.map