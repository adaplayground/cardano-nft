import { AccountInfo } from '@solana/web3.js';
import { ParsedAccount } from '../common/types/account-types';
import { Metadata } from '../common/types/metaData-types';
export declare const processSimpleMetaData: (account: AccountInfo<Buffer>, pubkey: string) => Promise<ParsedAccount<Metadata> | null | undefined>;
//# sourceMappingURL=processMetaData.d.ts.map