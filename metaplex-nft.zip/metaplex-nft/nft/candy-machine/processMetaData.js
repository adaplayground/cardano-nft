"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.processSimpleMetaData = void 0;
const utils_1 = require("../common/utils");
const metaData_types_1 = require("../common/types/metaData-types");
const processSimpleMetaData = async (account, pubkey) => {
    if (!isMetadataAccount(account))
        return null;
    try {
        if (isMetadataV1Account(account)) {
            const metadata = (0, metaData_types_1.decodeMetadata)(account.data);
            if ((0, utils_1.isValidHttpUrl)(metadata.data.uri)) {
                const parsedAccount = {
                    pubkey,
                    account,
                    info: metadata,
                };
                return parsedAccount;
                // await setter('metadataByMint', metadata.mint, parsedAccount);
                // await setter('metadataByMetadata', pubkey, parsedAccount);
            }
        }
    }
    catch {
        return null;
    }
};
exports.processSimpleMetaData = processSimpleMetaData;
const isMetadataAccount = (account) => account && (0, utils_1.pubkeyToString)(account.owner) === utils_1.METADATA_PROGRAM_ID;
const isMetadataV1Account = (account) => account.data[0] === metaData_types_1.MetadataKey.MetadataV1;
const isEditionV1Account = (account) => account.data[0] === metaData_types_1.MetadataKey.EditionV1;
const isMasterEditionAccount = (account) => account.data[0] === metaData_types_1.MetadataKey.MasterEditionV1 ||
    account.data[0] === metaData_types_1.MetadataKey.MasterEditionV2;
const isMasterEditionV1 = (me) => {
    return me.key === metaData_types_1.MetadataKey.MasterEditionV1;
};
