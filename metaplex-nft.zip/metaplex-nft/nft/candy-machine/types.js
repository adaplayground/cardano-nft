"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigData = void 0;
class ConfigData {
    name;
    symbol;
    uri;
    sellerFeeBasisPoints;
    creators;
    maxNumberOfLines;
    isMutable;
    maxSupply;
    retainAuthority;
    constructor(args) {
        this.name = args.name;
        this.symbol = args.symbol;
        this.uri = args.uri;
        this.sellerFeeBasisPoints = args.sellerFeeBasisPoints;
        this.creators = args.creators;
        this.maxNumberOfLines = args.maxNumberOfLines;
        this.isMutable = args.isMutable;
        this.maxSupply = args.maxSupply;
        this.retainAuthority = args.retainAuthority;
    }
}
exports.ConfigData = ConfigData;
