import { Connection } from '@solana/web3.js';
import { StringPublicKey } from '../../common/utils';
import { WalletSigner } from '../../common/models/wallet';
export declare function sendSignMetadata(connection: Connection, wallet: WalletSigner, metadata: StringPublicKey): Promise<void>;
//# sourceMappingURL=sendSignMetadata.d.ts.map