"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendSignMetadata = void 0;
const wallet_adapter_base_1 = require("@solana/wallet-adapter-base");
const connections_1 = require("../../common/utils/connections");
const metaData_types_1 = require("../../common/types/metaData-types");
async function sendSignMetadata(connection, wallet, metadata) {
    if (!wallet.publicKey)
        throw new wallet_adapter_base_1.WalletNotConnectedError();
    const signers = [];
    const instructions = [];
    await (0, metaData_types_1.signMetadata)(metadata, wallet.publicKey.toBase58(), instructions);
    await (0, connections_1.sendTransactionWithRetry)(connection, wallet, instructions, signers, 'single');
}
exports.sendSignMetadata = sendSignMetadata;
