import BN from 'bn.js';
export declare const TEN: BN;
export declare const HALF_WAD: BN;
export declare const WAD: BN;
export declare const RAY: BN;
export declare const ZERO: BN;
//# sourceMappingURL=math.d.ts.map