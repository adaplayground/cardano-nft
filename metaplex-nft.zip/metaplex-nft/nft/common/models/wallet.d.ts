import { WalletAdapter } from '@solana/wallet-adapter-base';
export declare type WalletSigner = Pick<WalletAdapter, 'publicKey' | 'signTransaction' | 'signAllTransactions'>;
//# sourceMappingURL=wallet.d.ts.map