export declare const extendBorsh: () => void;
//# sourceMappingURL=borsh.d.ts.map