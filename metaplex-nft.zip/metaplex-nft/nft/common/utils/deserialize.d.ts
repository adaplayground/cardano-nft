import { MintInfo } from '@solana/spl-token';
export declare const deserializeAccount: (data: Buffer) => any;
export declare const deserializeMint: (data: Buffer) => MintInfo;
//# sourceMappingURL=deserialize.d.ts.map