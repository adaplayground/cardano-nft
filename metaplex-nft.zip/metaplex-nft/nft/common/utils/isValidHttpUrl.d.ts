export declare function isValidHttpUrl(text: string): boolean;
//# sourceMappingURL=isValidHttpUrl.d.ts.map