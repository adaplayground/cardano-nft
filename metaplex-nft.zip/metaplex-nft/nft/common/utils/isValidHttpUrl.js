"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isValidHttpUrl = void 0;
function isValidHttpUrl(text) {
    return text.startsWith('http:') || text.startsWith('https:');
}
exports.isValidHttpUrl = isValidHttpUrl;
