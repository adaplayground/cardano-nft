import { AccountInfo } from '@solana/web3.js';
import { TokenAccount } from '../../common/models/account';
import { ParsedAccountBase } from '../../common/types/account-types';
import { StringPublicKey } from '../../common/utils/index';
export declare const MintParser: (pubKey: StringPublicKey, info: AccountInfo<Buffer>) => ParsedAccountBase;
export declare const TokenAccountParser: (pubKey: StringPublicKey, info: AccountInfo<Buffer>) => TokenAccount | undefined;
export declare const GenericAccountParser: (pubKey: StringPublicKey, info: AccountInfo<Buffer>) => ParsedAccountBase;
//# sourceMappingURL=parsesrs.d.ts.map