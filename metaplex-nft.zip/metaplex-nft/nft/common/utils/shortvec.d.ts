export declare function decodeLength(bytes: Array<number>): number;
export declare function encodeLength(bytes: Array<number>, len: number): void;
//# sourceMappingURL=shortvec.d.ts.map