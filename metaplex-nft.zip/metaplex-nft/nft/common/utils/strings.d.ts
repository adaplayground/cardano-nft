export declare function toUTF8Array(str: string): number[];
export declare function fromUTF8Array(data: number[]): string;
//# sourceMappingURL=strings.d.ts.map