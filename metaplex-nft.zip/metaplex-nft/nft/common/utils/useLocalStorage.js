"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.useLocalStorage = void 0;
const memoryLocalStorage_1 = __importDefault(require("../../utils/memoryLocalStorage"));
const useLocalStorage = () => {
    const getItem = (key) => {
        return memoryLocalStorage_1.default.getItem(key);
    };
    const setItem = (key, value) => {
        try {
            memoryLocalStorage_1.default.setItem(key, value);
            return true;
        }
        catch {
            return false;
        }
    };
    const removeItem = (key) => {
        memoryLocalStorage_1.default.removeItem(key);
    };
    return {
        getItem,
        setItem,
        removeItem,
    };
};
exports.useLocalStorage = useLocalStorage;
