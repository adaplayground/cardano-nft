/// <reference types="react" />
import { Connection } from '@solana/web3.js';
import { TokenInfo } from '@solana/spl-token-registry';
import { ENV } from '../common/utils/connections';
export declare function ConnectionProvider({ children }: {
    children?: any;
}): JSX.Element;
export declare function useConnection(): Connection;
export declare function useConnectionConfig(): {
    endpoint: string;
    setEndpoint: (val: string) => void;
    env: ENV;
    tokens: TokenInfo[];
    tokenMap: Map<string, TokenInfo>;
};
//# sourceMappingURL=connection.d.ts.map