"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.useConnectionConfig = exports.useConnection = exports.ConnectionProvider = void 0;
const utils_1 = require("../common/utils");
const web3_js_1 = require("@solana/web3.js");
const react_1 = __importStar(require("react"));
const spl_token_registry_1 = require("@solana/spl-token-registry");
const connections_1 = require("../common/utils/connections");
const react_router_dom_1 = require("react-router-dom");
function useQuerySearch() {
    return new URLSearchParams((0, react_router_dom_1.useLocation)().search);
}
const DEFAULT = connections_1.ENDPOINTS[0].endpoint;
const ConnectionContext = react_1.default.createContext({
    endpoint: DEFAULT,
    setEndpoint: () => {
    },
    connection: new web3_js_1.Connection(DEFAULT, 'recent'),
    env: connections_1.ENDPOINTS[0].name,
    tokens: [],
    tokenMap: new Map(),
});
function ConnectionProvider({ children = undefined }) {
    const searchParams = useQuerySearch();
    const network = searchParams.get('network');
    const queryEndpoint = network && connections_1.ENDPOINTS.find(({ name }) => name.startsWith(network))?.endpoint;
    const [savedEndpoint, setEndpoint] = (0, utils_1.useLocalStorageState)('connectionEndpoint', connections_1.ENDPOINTS[0].endpoint);
    const endpoint = queryEndpoint || savedEndpoint;
    const connection = (0, react_1.useMemo)(() => new web3_js_1.Connection(endpoint, 'recent'), [endpoint]);
    const env = connections_1.ENDPOINTS.find(end => end.endpoint === endpoint)?.name || connections_1.ENDPOINTS[0].name;
    const [tokens, setTokens] = (0, react_1.useState)([]);
    const [tokenMap, setTokenMap] = (0, react_1.useState)(new Map());
    (0, react_1.useEffect)(() => {
        // fetch token files
        new spl_token_registry_1.TokenListProvider().resolve().then(container => {
            const list = container
                .excludeByTag('nft')
                .filterByChainId(connections_1.ENDPOINTS.find(end => end.endpoint === endpoint)?.ChainId ||
                spl_token_registry_1.ENV.MainnetBeta)
                .getList();
            const knownMints = [...list].reduce((map, item) => {
                map.set(item.address, item);
                return map;
            }, new Map());
            setTokenMap(knownMints);
            setTokens(list);
        });
    }, [env]);
    // The websocket library solana/web3.js uses closes its websocket connection when the subscription list
    // is empty after opening its first time, preventing subsequent subscriptions from receiving responses.
    // This is a hack to prevent the list from every getting empty
    (0, react_1.useEffect)(() => {
        const id = connection.onAccountChange(web3_js_1.Keypair.generate().publicKey, () => {
        });
        return () => {
            connection.removeAccountChangeListener(id);
        };
    }, [connection]);
    (0, react_1.useEffect)(() => {
        const id = connection.onSlotChange(() => null);
        return () => {
            connection.removeSlotChangeListener(id);
        };
    }, [connection]);
    return (react_1.default.createElement(ConnectionContext.Provider, { value: {
            endpoint,
            setEndpoint,
            connection,
            tokens,
            tokenMap,
            env,
        } }, children));
}
exports.ConnectionProvider = ConnectionProvider;
function useConnection() {
    return (0, react_1.useContext)(ConnectionContext).connection;
}
exports.useConnection = useConnection;
function useConnectionConfig() {
    const context = (0, react_1.useContext)(ConnectionContext);
    return {
        endpoint: context.endpoint,
        setEndpoint: context.setEndpoint,
        env: context.env,
        tokens: context.tokens,
        tokenMap: context.tokenMap,
    };
}
exports.useConnectionConfig = useConnectionConfig;
