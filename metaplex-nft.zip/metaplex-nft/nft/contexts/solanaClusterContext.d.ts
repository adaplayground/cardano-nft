/// <reference types="react" />
import { WalletAdapterNetwork } from '@solana/wallet-adapter-base';
declare function useSolanaCluster(): {
    solanaCluster: WalletAdapterNetwork;
    setSolanaCluster: (cluster: WalletAdapterNetwork) => void;
};
export declare function SolanaClusterProvider({ initValue, children }: {
    initValue: any;
    children: any;
}): JSX.Element;
export default useSolanaCluster;
//# sourceMappingURL=solanaClusterContext.d.ts.map