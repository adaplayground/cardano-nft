import { MintMonitor, WebWalletSigner } from '../candy-machine/types';
import { StringPublicKey } from '../common/utils';
import { Attribute, Creator } from '../common/types/metaData-types';
export declare const mintOneNft: (image: File | null, meta: {
    name: string;
    symbol: string;
    description: string;
    image: string | undefined;
    animation_url: string | undefined;
    attributes: Attribute[] | undefined;
    external_url: string;
    properties: any;
    creators: Creator[] | null;
    sellerFeeBasisPoints: number;
    collection_name?: string | undefined;
    collection_family?: string | undefined;
}, wallet: WebWalletSigner, env: string, price: string, mintMonitor: MintMonitor, solTreasuryAccount: any, cacheStorage: any) => Promise<{
    metadataAccount: StringPublicKey;
    arweaveLink: string;
} | void>;
export declare const mintOneNftWithImageLink: (imageLink: string, meta: {
    name: string;
    symbol: string;
    description: string;
    image: string | undefined;
    animation_url: string | undefined;
    attributes: Attribute[] | undefined;
    external_url: string;
    properties: any;
    creators: Creator[] | null;
    sellerFeeBasisPoints: number;
    collection_name?: string;
    collection_family?: string;
}, wallet: WebWalletSigner, env: string, price: string, mintMonitor: MintMonitor, solTreasuryAccount: any, cacheStorage: any) => Promise<{
    metadataAccount: StringPublicKey;
    arweaveLink: string;
} | void>;
//# sourceMappingURL=index.d.ts.map