"use strict";
// on demand mint, without any pre-paid fee for seller
// or diy mint on demand if not set solTreasuryAccount
Object.defineProperty(exports, "__esModule", { value: true });
exports.mintOneNftWithImageLink = exports.mintOneNft = void 0;
const anchor_1 = require("@project-serum/anchor");
const nft_1 = require("../diy-mint/nft");
const candy_machine_1 = require("../candy-machine");
const ipfs_1 = require("../candy-machine/ipfs");
const mintOneNft = async (image, meta, wallet, env, price, mintMonitor, solTreasuryAccount = null, cacheStorage) => {
    if (image) {
        const cacheName = 'cache';
        const solConnection = new anchor_1.web3.Connection(anchor_1.web3.clusterApiUrl(env));
        return await (0, nft_1.mintSingleNFT)(solConnection, wallet, env, image, meta, mintMonitor, cacheName, cacheStorage, price, solTreasuryAccount);
    }
};
exports.mintOneNft = mintOneNft;
const mintOneNftWithImageLink = async (imageLink, meta, wallet, env, price, mintMonitor, solTreasuryAccount = null, cacheStorage) => {
    if (imageLink) {
        const cacheName = 'cache';
        const solConnection = new anchor_1.web3.Connection(anchor_1.web3.clusterApiUrl(env));
        //const manifestBuffer = Buffer.from(JSON.stringify(image0_meta));
        let link = null;
        if (mintMonitor) {
            mintMonitor(candy_machine_1.MintStatus.UpLoad, cacheStorage);
        }
        try {
            const metadata = meta;
            const metadataContent = metadata;
            if (metadata.collection_name && metadata.collection_family) {
                metadataContent['collection'] = {
                    name: metadata.collection_name,
                    family: metadata.collection_family,
                };
            }
            const manifestBuffer = Buffer.from(JSON.stringify(metadataContent));
            link = await (0, ipfs_1.ipfsUploadWithMediaLink)(ipfs_1.ipfsConfig, imageLink, manifestBuffer);
        }
        catch (e) {
            console.log(e);
        }
        return await (0, nft_1.mintSingleNFTWithMetaLink)(solConnection, wallet, env, link, meta, mintMonitor, cacheName, cacheStorage, price, solTreasuryAccount);
    }
};
exports.mintOneNftWithImageLink = mintOneNftWithImageLink;
