import { Connection } from '@solana/web3.js';
import { ENV } from '../common/utils/connections';
import { MintMonitor, WebWalletSigner } from '../candy-machine/types';
import { StringPublicKey } from '../common/utils/ids';
export declare const toBase64: (file: any) => Promise<unknown>;
export declare const mintSingleNFT: (connection: Connection, wallet: WebWalletSigner, env: ENV, files: File, metadata: any, mintMonitor: MintMonitor, cacheName: string, cacheStorage: any, price?: string, solTreasuryAccount?: any, maxSupply?: number) => Promise<void | {
    metadataAccount: StringPublicKey;
    arweaveLink: string;
}>;
export declare const mintSingleNFTWithMetaLink: (connection: Connection, wallet: WebWalletSigner, env: ENV, metaLink: string, metadata: any, mintMonitor: MintMonitor, cacheName: string, cacheStorage: any, price?: string, solTreasuryAccount?: any, maxSupply?: number) => Promise<void | {
    metadataAccount: StringPublicKey;
    arweaveLink: string;
}>;
//# sourceMappingURL=nft.d.ts.map