"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mintSingleNFTWithMetaLink = exports.mintSingleNFT = exports.toBase64 = void 0;
const spl_token_1 = require("@solana/spl-token");
const web3_js_1 = require("@solana/web3.js");
const crypto_1 = __importDefault(require("crypto"));
const bn_js_1 = __importDefault(require("bn.js"));
const connections_1 = require("../common/utils/connections");
const constants_1 = require("../common/constants");
const candy_machine_1 = require("../candy-machine");
const cache_1 = require("../candy-machine/actions/cache");
const ipfs_1 = require("../candy-machine/ipfs");
const various_1 = require("../candy-machine/actions/various");
const ids_1 = require("../common/utils/ids");
const utils_1 = require("../common/utils");
const account_1 = require("../common/actions/account");
const metaData_types_1 = require("../common/types/metaData-types");
const RESERVED_METADATA = 'metadata.json';
const toBase64 = file => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
        // @ts-ignore
        resolve(reader.result);
    };
    reader.onerror = error => reject(error);
});
exports.toBase64 = toBase64;
const mintSingleNFT = async (connection, wallet, env, files, metadata, mintMonitor, cacheName, cacheStorage, price = '0', solTreasuryAccount = null, maxSupply = 1) => {
    if (!wallet?.publicKey)
        return;
    const savedContent = (0, cache_1.loadCache)(cacheName, env, cacheStorage);
    const cacheContent = savedContent || {};
    const metadataContent = {
        name: metadata.name,
        symbol: metadata.symbol,
        description: metadata.description,
        seller_fee_basis_points: metadata.sellerFeeBasisPoints,
        image: metadata.image,
        animation_url: metadata.animation_url,
        attributes: metadata.attributes,
        external_url: metadata.external_url,
        properties: metadata.properties,
    };
    if (metadata.collection_name && metadata.collection_family) {
        metadataContent['collection'] = {
            name: metadata.collection_name,
            family: metadata.collection_family,
        };
    }
    const realFiles = [
        files,
        new File([JSON.stringify(metadataContent)], RESERVED_METADATA),
    ];
    const { instructions: pushInstructions, signers: pushSigners } = await prepPayForFilesTxn(wallet, realFiles, metadata, price, solTreasuryAccount);
    const TOKEN_PROGRAM_ID = (0, utils_1.programIds)().token;
    // Allocate memory for the account
    const mintRent = await connection.getMinimumBalanceForRentExemption(spl_token_1.MintLayout.span);
    cacheContent.mintRent = mintRent;
    // const accountRent = await connection.getMinimumBalanceForRentExemption(
    //   AccountLayout.span,
    // );
    // This owner is a temporary signer and owner of metadata we use to circumvent requesting signing
    // twice post Arweave. We store in an account (payer) and use it post-Arweave to update MD with new link
    // then give control back to the user.
    // const payer = new Account();
    const payerPublicKey = wallet.publicKey.toBase58();
    const instructions = [...pushInstructions];
    const signers = [...pushSigners];
    cacheContent.payerPublicKey = payerPublicKey;
    // This is only temporarily owned by wallet...transferred to program by createMasterEdition below
    const mintKey = (0, account_1.createMint)(instructions, wallet.publicKey, mintRent, 0, 
    // Some weird bug with phantom where it's public key doesnt mesh with data encode wellff
    (0, ids_1.toPublicKey)(payerPublicKey), (0, ids_1.toPublicKey)(payerPublicKey), signers).toBase58();
    cacheContent.mintKey = mintKey;
    const recipientKey = (await (0, utils_1.findProgramAddress)([
        wallet.publicKey.toBuffer(),
        (0, utils_1.programIds)().token.toBuffer(),
        (0, ids_1.toPublicKey)(mintKey).toBuffer(),
    ], (0, utils_1.programIds)().associatedToken))[0];
    if (mintMonitor) {
        mintMonitor(candy_machine_1.MintStatus.Create, cacheStorage);
    }
    (0, account_1.createAssociatedTokenAccountInstruction)(instructions, (0, ids_1.toPublicKey)(recipientKey), wallet.publicKey, wallet.publicKey, (0, ids_1.toPublicKey)(mintKey));
    const image = await (0, exports.toBase64)(files);
    // @ts-ignore
    const imageBase64 = image.replace('data:image/png;base64,', '');
    const manifestBuffer = Buffer.from(JSON.stringify(metadataContent));
    //const manifestBuffer = Buffer.from(JSON.stringify(image0_meta));
    let link = null;
    if (mintMonitor) {
        mintMonitor(candy_machine_1.MintStatus.UpLoad, cacheStorage);
    }
    try {
        link = await (0, ipfs_1.ipfsUpload)(ipfs_1.ipfsConfig, imageBase64, manifestBuffer);
    }
    catch (e) {
        console.log(e);
    }
    const metadataAccount = await (0, metaData_types_1.createMetadata)(new metaData_types_1.Data({
        symbol: metadata.symbol,
        name: metadata.name,
        // @ts-ignore
        uri: link,
        sellerFeeBasisPoints: metadata.sellerFeeBasisPoints,
        creators: metadata.creators,
    }), payerPublicKey, mintKey, payerPublicKey, instructions, wallet.publicKey.toBase58());
    let arweaveLink = '';
    if (link && wallet.publicKey) {
        arweaveLink = link;
        const updateInstructions = instructions;
        const updateSigners = signers;
        updateInstructions.push(spl_token_1.Token.createMintToInstruction(TOKEN_PROGRAM_ID, (0, ids_1.toPublicKey)(mintKey), (0, ids_1.toPublicKey)(recipientKey), (0, ids_1.toPublicKey)(payerPublicKey), [], 1));
        if (mintMonitor) {
            mintMonitor(candy_machine_1.MintStatus.Mint, cacheStorage);
        }
        // // In this instruction, mint authority will be removed from the main mint, while
        // // minting authority will be maintained for the Printing mint (which we want.)
        await (0, metaData_types_1.createMasterEdition)(maxSupply !== undefined ? new bn_js_1.default(maxSupply) : undefined, mintKey, payerPublicKey, payerPublicKey, payerPublicKey, updateInstructions);
        const txid = await (0, connections_1.sendTransactionWithRetry)(connection, wallet, updateInstructions, updateSigners);
        cacheContent.txid = txid;
        if (mintMonitor) {
            mintMonitor(candy_machine_1.MintStatus.Sign, cacheStorage);
        }
    }
    (0, cache_1.saveCache)(cacheName, env, cacheContent, cacheStorage);
    return { metadataAccount, arweaveLink };
};
exports.mintSingleNFT = mintSingleNFT;
const mintSingleNFTWithMetaLink = async (connection, wallet, env, metaLink, metadata, mintMonitor, cacheName, cacheStorage, price = '0', solTreasuryAccount = null, maxSupply = 1) => {
    if (!wallet?.publicKey)
        return;
    const savedContent = (0, cache_1.loadCache)(cacheName, env, cacheStorage);
    const cacheContent = savedContent || {};
    const { instructions: pushInstructions, signers: pushSigners } = await prepPayForFilesTxnForIpfsHolder(wallet, price, solTreasuryAccount);
    // Allocate memory for the account
    const mintRent = await connection.getMinimumBalanceForRentExemption(spl_token_1.MintLayout.span);
    cacheContent.mintRent = mintRent;
    // const accountRent = await connection.getMinimumBalanceForRentExemption(
    //   AccountLayout.span,
    // );
    // This owner is a temporary signer and owner of metadata we use to circumvent requesting signing
    // twice post Arweave. We store in an account (payer) and use it post-Arweave to update MD with new link
    // then give control back to the user.
    // const payer = new Account();
    const payerPublicKey = wallet.publicKey.toBase58();
    const instructions = [...pushInstructions];
    const signers = [...pushSigners];
    cacheContent.payerPublicKey = payerPublicKey;
    // This is only temporarily owned by wallet...transferred to program by createMasterEdition below
    const mintKey = (0, account_1.createMint)(instructions, wallet.publicKey, mintRent, 0, 
    // Some weird bug with phantom where it's public key doesnt mesh with data encode wellff
    (0, ids_1.toPublicKey)(payerPublicKey), (0, ids_1.toPublicKey)(payerPublicKey), signers).toBase58();
    cacheContent.mintKey = mintKey;
    const recipientKey = (await (0, utils_1.findProgramAddress)([
        wallet.publicKey.toBuffer(),
        (0, utils_1.programIds)().token.toBuffer(),
        (0, ids_1.toPublicKey)(mintKey).toBuffer(),
    ], (0, utils_1.programIds)().associatedToken))[0];
    if (mintMonitor) {
        mintMonitor(candy_machine_1.MintStatus.Create, cacheStorage);
    }
    (0, account_1.createAssociatedTokenAccountInstruction)(instructions, (0, ids_1.toPublicKey)(recipientKey), wallet.publicKey, wallet.publicKey, (0, ids_1.toPublicKey)(mintKey));
    let arweaveLink = metaLink;
    const TOKEN_PROGRAM_ID = (0, utils_1.programIds)().token;
    const metadataAccount = await (0, metaData_types_1.createMetadata)(new metaData_types_1.Data({
        symbol: metadata.symbol,
        name: metadata.name,
        uri: arweaveLink,
        sellerFeeBasisPoints: metadata.sellerFeeBasisPoints,
        creators: metadata.creators,
    }), payerPublicKey, mintKey, payerPublicKey, instructions, wallet.publicKey.toBase58());
    if (wallet.publicKey) {
        const updateInstructions = instructions;
        const updateSigners = signers;
        updateInstructions.push(spl_token_1.Token.createMintToInstruction(TOKEN_PROGRAM_ID, (0, ids_1.toPublicKey)(mintKey), (0, ids_1.toPublicKey)(recipientKey), (0, ids_1.toPublicKey)(payerPublicKey), [], 1));
        if (mintMonitor) {
            mintMonitor(candy_machine_1.MintStatus.Mint, cacheStorage);
        }
        // // In this instruction, mint authority will be removed from the main mint, while
        // // minting authority will be maintained for the Printing mint (which we want.)
        await (0, metaData_types_1.createMasterEdition)(maxSupply !== undefined ? new bn_js_1.default(maxSupply) : undefined, mintKey, payerPublicKey, payerPublicKey, payerPublicKey, updateInstructions);
        const txid = await (0, connections_1.sendTransactionWithRetry)(connection, wallet, updateInstructions, updateSigners);
        cacheContent.txid = txid;
        if (mintMonitor) {
            mintMonitor(candy_machine_1.MintStatus.Sign, cacheStorage);
        }
    }
    (0, cache_1.saveCache)(cacheName, env, cacheContent, cacheStorage);
    return { metadataAccount, arweaveLink };
};
exports.mintSingleNFTWithMetaLink = mintSingleNFTWithMetaLink;
const prepPayForFilesTxnForIpfsHolder = async (wallet, price, solTreasuryAccount = null) => {
    const instructions = [];
    const signers = [];
    if (wallet.publicKey) {
        instructions.push(web3_js_1.SystemProgram.transfer({
            fromPubkey: wallet.publicKey,
            toPubkey: constants_1.IPFS_SOL_HOLDER_ID,
            lamports: 2300000,
        }));
        if (solTreasuryAccount) {
            const parsedPrice = (0, various_1.parsePrice)(price);
            instructions.push(web3_js_1.SystemProgram.transfer({
                fromPubkey: wallet.publicKey,
                toPubkey: solTreasuryAccount,
                lamports: parsedPrice,
            }));
        }
    }
    return {
        instructions,
        signers,
    };
};
const prepPayForFilesTxn = async (wallet, files, metadata, price, solTreasuryAccount = null) => {
    const memo = (0, utils_1.programIds)().memo;
    const instructions = [];
    const signers = [];
    if (wallet.publicKey) {
        instructions.push(web3_js_1.SystemProgram.transfer({
            fromPubkey: wallet.publicKey,
            toPubkey: constants_1.IPFS_SOL_HOLDER_ID,
            lamports: 2300000,
        }));
        if (solTreasuryAccount) {
            const parsedPrice = (0, various_1.parsePrice)(price);
            instructions.push(web3_js_1.SystemProgram.transfer({
                fromPubkey: wallet.publicKey,
                toPubkey: solTreasuryAccount,
                lamports: parsedPrice,
            }));
        }
    }
    for (let i = 0; i < files.length; i++) {
        const hashSum = crypto_1.default.createHash('sha256');
        hashSum.update(await files[i].text());
        const hex = hashSum.digest('hex');
        instructions.push(new web3_js_1.TransactionInstruction({
            keys: [],
            programId: memo,
            data: Buffer.from(hex),
        }));
    }
    return {
        instructions,
        signers,
    };
};
