declare const dateString: (d: Date) => string;
declare const formatDate: (d: Date) => string;
declare const encryptString: (key: any) => any;
declare const decryptString: (value: any) => any;
declare const randomIntFromInterval: (min: any, max: any) => number;
declare const sanitiseString: (str: string) => string;
export { dateString, formatDate, encryptString, decryptString, randomIntFromInterval, sanitiseString, };
//# sourceMappingURL=helpers.d.ts.map