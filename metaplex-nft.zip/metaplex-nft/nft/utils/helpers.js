"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sanitiseString = exports.randomIntFromInterval = exports.decryptString = exports.encryptString = exports.formatDate = exports.dateString = void 0;
const aes_1 = __importDefault(require("crypto-js/aes"));
const enc_utf8_1 = __importDefault(require("crypto-js/enc-utf8"));
const asePassphrase = '5YWKbD2DgQjLttKe5BSJMTJyqN5dJpRmfR3vFWVVEqZZfnG32kYeVmCc7RR9bjGU';
const dateString = (d) => d.getFullYear() +
    '_' +
    ('0' + (d.getMonth() + 1)).slice(-2) +
    '_' +
    ('0' + d.getDate()).slice(-2) +
    '_' +
    ('0' + d.getHours()).slice(-2) +
    '_' +
    ('0' + d.getMinutes()).slice(-2) +
    '_' +
    ('0' + d.getSeconds()).slice(-2) +
    '_' +
    ('0' + d.getMilliseconds()).slice(-3);
exports.dateString = dateString;
const formatDate = (d) => d.getFullYear() +
    '_' +
    ('0' + (d.getMonth() + 1)).slice(-2) +
    '_' +
    ('0' + d.getDate()).slice(-2) +
    '_' +
    ('0' + d.getHours()).slice(-2) +
    '_' +
    ('0' + d.getMinutes()).slice(-2) +
    '_' +
    ('0' + d.getSeconds()).slice(-2) +
    '_' +
    ('0' + d.getMilliseconds()).slice(-3);
exports.formatDate = formatDate;
const encryptString = (key) => {
    return aes_1.default.encrypt(key.toString(), asePassphrase).toString();
};
exports.encryptString = encryptString;
const decryptString = (value) => {
    const decrypted = aes_1.default.decrypt(value, asePassphrase);
    return decrypted.toString(enc_utf8_1.default);
};
exports.decryptString = decryptString;
const randomIntFromInterval = (min, max) => {
    // min and max included
    return Math.floor(Math.random() * (max - min + 1) + min);
};
exports.randomIntFromInterval = randomIntFromInterval;
const sanitiseString = (str) => str.replace(/[&\/\\#+()$~%.'":*?<>{}!\-_]/g, '');
exports.sanitiseString = sanitiseString;
