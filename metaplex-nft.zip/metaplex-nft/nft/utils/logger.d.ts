import log from 'loglevel';
declare const logger: log.RootLogger;
export default logger;
//# sourceMappingURL=logger.d.ts.map