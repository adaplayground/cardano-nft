"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const loglevel_1 = __importDefault(require("loglevel"));
const lodash_1 = require("lodash");
const helpers_1 = require("../utils/helpers");
loglevel_1.default.setLevel('INFO');
const originalFactory = loglevel_1.default.methodFactory;
loglevel_1.default.methodFactory = function (methodName, logLevel, loggerName) {
    const rawMethod = originalFactory(methodName, logLevel, loggerName);
    return function () {
        const currentDate = (0, helpers_1.formatDate)(new Date()) + '->';
        let messages = [];
        for (let i = 0; i < arguments.length; i++) {
            let original = arguments[i];
            if ((0, lodash_1.isObjectLike)(arguments[i])) {
                original = JSON.stringify(arguments[i]);
            }
            if (original === undefined) {
                console.log('logging undefined message');
            }
            messages.push(original);
        }
        rawMethod.apply(undefined, [currentDate, ...messages]);
    };
};
loglevel_1.default.setLevel(loglevel_1.default.getLevel()); // Be sure to call setLevel method in order to apply plugin
const logger = loglevel_1.default;
exports.default = logger;
