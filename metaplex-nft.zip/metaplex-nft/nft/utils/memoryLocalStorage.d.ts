declare let cache: {};
declare const localStorageMemory: {
    length: number;
    getItem: (key: any) => any;
    setItem: (key: any, value: any) => void;
    removeItem: (key: any) => void;
    key: (index: any) => string | null;
    clear: () => void;
};
export default localStorageMemory;
export { cache };
//# sourceMappingURL=memoryLocalStorage.d.ts.map