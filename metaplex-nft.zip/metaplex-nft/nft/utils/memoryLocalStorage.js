"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cache = void 0;
let cache = {};
exports.cache = cache;
const localStorageMemory = {
    length: 0,
    getItem: key => {
        if (key in cache) {
            return cache[key];
        }
        return null;
    },
    setItem: (key, value) => {
        if (typeof value === 'undefined') {
            localStorageMemory.removeItem(key);
        }
        else {
            if (!cache.hasOwnProperty(key)) {
                localStorageMemory.length++;
            }
            cache[key] = '' + value;
        }
    },
    removeItem: key => {
        if (cache.hasOwnProperty(key)) {
            delete cache[key];
            localStorageMemory.length--;
        }
    },
    key: index => {
        return Object.keys(cache)[index] || null;
    },
    clear: () => {
        exports.cache = cache = {};
        localStorageMemory.length = 0;
    },
};
exports.default = localStorageMemory;
