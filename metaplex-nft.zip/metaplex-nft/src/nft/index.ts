import { initIpfs, ipfsCreds } from './candy-machine/ipfs';
import useSolanaCluster, { SolanaClusterProvider } from './contexts/solanaClusterContext';
import { CoingeckoProvider, useSolPrice } from './contexts/coingecko';
import {
  buyerBuyNftFromCandyMachine,
  diyMintOneNftWithCandyMachine,
  getMintStatusMessage,
  MintStatus,
} from './candy-machine';
import { WebWalletSigner } from './candy-machine/types';
import { mintOneNft, mintOneNftWithImageLink } from './diy-mint';
import { dateString, randomIntFromInterval, sanitiseString } from './utils/helpers';
import { toBase64 } from './diy-mint/nft';
import { loadWalletKey } from './candy-machine/actions/accounts';
import logger from './utils/logger';
import { processSimpleMetaData } from './candy-machine/processMetaData';
import { TokenAccountParser } from './common/utils/parsesrs';
import { ParsedAccount } from './common/types/account-types';
import { programIds } from './common/utils';
import { Attribute, Creator, getMetadata, Metadata } from './common/types/metaData-types';
import { transferOneNft } from './candy-machine/operations';

export type { ipfsCreds, WebWalletSigner, ParsedAccount, Attribute, Creator };

export {
  MintStatus,
  Metadata,
  logger,
  dateString,
  randomIntFromInterval,
  sanitiseString,
  toBase64,
  initIpfs,
  useSolanaCluster,
  useSolPrice,
  CoingeckoProvider,
  processSimpleMetaData,
  TokenAccountParser,
  programIds,
  getMetadata,
  loadWalletKey,
  getMintStatusMessage,
  mintOneNft,
  diyMintOneNftWithCandyMachine,
  mintOneNftWithImageLink,
  buyerBuyNftFromCandyMachine,
  transferOneNft,
  SolanaClusterProvider,
};
